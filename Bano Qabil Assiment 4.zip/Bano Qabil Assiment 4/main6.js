// que 6 return all the values for a specified key in each object.

function getObjectValuesByKey(arr, key) {
    return arr.map(obj => obj[key]);
  }
  const myArr = [
    { name: 'Tahir', age: 28 },
    { name: ' Mujtaba', age: 22 },
    { name: 'Taimor', age: 27 }
  ];
  
  const values = getObjectValuesByKey(myArr, 'name');
  // Output: ["Tahir", "Mujtaba", "Taimor"]
  console.log(values); 
    