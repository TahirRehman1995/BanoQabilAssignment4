// function that takes an array of numbers as input 
// and returns the product of all the numbers in the array
function getProductOfNumbers(arr) {
    return arr.reduce((acc, cur) => acc * cur, 1);
  }
  const myArr = [2, 3, 4, 5,6,7,8,9,1,14,12,14];
  const product = getProductOfNumbers(myArr);
  console.log(product); // Output: 362880
    